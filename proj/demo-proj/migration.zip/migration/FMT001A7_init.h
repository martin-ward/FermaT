
                              /* Data initialisation routine: */

void
initialise_FMT001A7()
{
  memmove(wglobal, "\x00\x00\x00\x0C", 4);
}
